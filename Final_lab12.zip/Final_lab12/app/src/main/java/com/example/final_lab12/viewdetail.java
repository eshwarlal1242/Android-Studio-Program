package com.example.final_lab12;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class viewdetail extends AppCompatActivity {
    ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewdetail);

        imageView=findViewById(R.id.image);

        String url="https://firebasestorage.googleapis.com/v0/b/final-lab12.appspot.com/o/images%2F8b5a5424-0379-468d-8354-c32cab839da7?alt=media&token=1c7de6de-0bf0-4799-990c-ff6bc58f2ca8";//Retrieved url as mentioned above

        Glide.with(getApplicationContext()).load(url).into(imageView);

    }
}

